// Load the CSV data
d3.csv("./pokemon.csv").then(function(data) {
    console.log(data); // Check that the data is loaded correctly

    // Calculate total stats for each Pokémon and create table rows
    data.forEach(function(d) {
        // Calculate the total stat score by summing the relevant stats
        let totalStatScore = parseInt(d.Attack) + parseInt(d.Defense) + parseInt(d.HP) + parseInt(d.Speed);

        let row = d3.select("#pokemon-table tbody").append("tr");
        row.append("td").text(d.Name);  
        row.append("td").text(d["Type 1"]);  
        row.append("td").text(totalStatScore);
    });

    let maxSpeed = 0;
    let fastestPokemon = "";

    data.forEach(function(d) {

        let totalStatScore = parseInt(d.Attack) + parseInt(d.Defense) + parseInt(d.HP) + parseInt(d.Speed);

        let paragraph = d3.select("#pokemon-info")
            .append("p")
            .text(d.Name + " is a " + d["Type 1"] + " Pokemon with a total of " + totalStatScore + " stats.");

        if (parseInt(d.Speed) > maxSpeed) {
            maxSpeed = parseInt(d.Speed);
            fastestPokemon = d.Name;  // Make sure to store the Name
        }
    });

    // Highlight the Pokémon with the highest speed in red
    d3.selectAll("#pokemon-info p").each(function(d, i) {
        if (d3.select(this).text().includes(fastestPokemon)) {
            d3.select(this).style("color", "red");  // Set color to red for the fastest Pokémon
        }
    });
});

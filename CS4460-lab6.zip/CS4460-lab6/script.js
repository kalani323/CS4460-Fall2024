
const width = 800;
const height = 500;
const margin = { top: 20, right: 30, bottom: 50, left: 50 };

const svg = d3.select("#chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

const xScale = d3.scaleLinear().range([0, width]);
const yScale = d3.scaleLinear().range([height, 0]);

const xAxis = svg.append("g").attr("transform", `translate(0,${height})`);
const yAxis = svg.append("g");

const colorScale = d3.scaleOrdinal()
    .domain(["Public", "Private"])
    .range(["steelblue", "orange"]);

d3.csv("colleges.csv").then(data => {
    data.forEach(d => {
        d["Average Cost"] = +d["Average Cost"];
        d["Median Earnings 8 years After Entry"] = +d["Median Earnings 8 years After Entry"];
    });

    const updateChart = (regionFilter, controlFilter) => {
        const filteredData = data.filter(d => {
            const matchesRegion = regionFilter === "all" || d.Region === regionFilter;
            const matchesControl = controlFilter === "all" || d.Control === controlFilter;
            return matchesRegion && matchesControl;
        });

        xScale.domain(d3.extent(filteredData, d => d["Average Cost"]));
        yScale.domain(d3.extent(filteredData, d => d["Median Earnings 8 years After Entry"]));

        xAxis.call(d3.axisBottom(xScale).ticks(10));
        yAxis.call(d3.axisLeft(yScale).ticks(10));

        const dots = svg.selectAll(".dot").data(filteredData, d => d.Name);

        dots.enter()
            .append("circle")
            .attr("class", "dot")
            .attr("cx", d => xScale(d["Average Cost"]))
            .attr("cy", d => yScale(d["Median Earnings 8 years After Entry"]))
            .attr("r", 5)
            .attr("fill", d => colorScale(d.Control))
            .merge(dots)
            .transition()
            .duration(500)
            .attr("cx", d => xScale(d["Average Cost"]))
            .attr("cy", d => yScale(d["Median Earnings 8 years After Entry"]))
            .attr("fill", d => colorScale(d.Control));

        dots.exit().remove();

        const tooltip = d3.select("body")
            .append("div")
            .style("position", "absolute")
            .style("background", "#f4f4f4")
            .style("padding", "5px")
            .style("border", "1px solid #ddd")
            .style("border-radius", "5px")
            .style("opacity", 0);

        svg.selectAll(".dot")
            .on("mouseover", (event, d) => {
                tooltip.transition().duration(200).style("opacity", 1);
                tooltip.html(`College: ${d.Name}<br>Cost: $${d["Average Cost"]}<br>Earnings: $${d["Median Earnings 8 years After Entry"]}<br>Control: ${d.Control}`)
                    .style("left", `${event.pageX + 10}px`)
                    .style("top", `${event.pageY - 10}px`);
            })
            .on("mouseout", () => {
                tooltip.transition().duration(500).style("opacity", 0);
            });
    };

    const regionDropdown = d3.select("#region");
    const regions = Array.from(new Set(data.map(d => d.Region))).sort();
    regions.forEach(region => {
        regionDropdown.append("option").text(region).attr("value", region);
    });

    regionDropdown.on("change", () => {
        const selectedRegion = regionDropdown.node().value;
        const selectedControl = d3.select("#control").node().value;
        updateChart(selectedRegion, selectedControl);
    });

    const controlDropdown = d3.select("#control");
    controlDropdown.on("change", () => {
        const selectedRegion = regionDropdown.node().value;
        const selectedControl = controlDropdown.node().value;
        updateChart(selectedRegion, selectedControl);
    });

    updateChart("all", "all");
});

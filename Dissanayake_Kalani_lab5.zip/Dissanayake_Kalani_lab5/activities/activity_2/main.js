var width = 500;
var height = 500;
var width2 = 900;
var padding = { t: 60, r: 40, b: 30, l: 120 };

var barChartWidth = width2 - padding.l - padding.r;
var chartHeight = height - padding.t - padding.b;

d3.csv("cereals.csv", function (csv) {
    csv.forEach(d => {
        d.Calories = +d.Calories;
        d.Fat = +d.Fat;
        d.Protein = +d.Protein;
        d.Carb = +d.Carb;
    });

    var fatExtent = d3.extent(csv, d => d.Fat);
    var carbExtent = d3.extent(csv, d => d.Carb);
    var proteinExtent = d3.extent(csv, d => d.Protein);
    var cerealNames = csv.map(d => d.CerealName);

    var xScale = d3.scaleBand().domain(cerealNames).range([0, barChartWidth]).padding(0.2);
    var yScale = d3.scaleLinear().domain(fatExtent).range([chartHeight, 30]);
    var xScale2 = d3.scaleLinear().domain([0, proteinExtent[1]]).range([50, 470]);
    var yScale2 = d3.scaleLinear().domain(carbExtent).range([470, 30]);

    var xAxis = d3.axisBottom().scale(xScale);
    var yAxis = d3.axisLeft().scale(yScale);
    var xAxis2 = d3.axisBottom().scale(xScale2);
    var yAxis2 = d3.axisLeft().scale(yScale2);

    var chart1 = d3.select("#chart1").append("svg").attr("width", width2).attr("height", 600);
    var chart2 = d3.select("#chart2").append("svg").attr("width", width).attr("height", height);

    // Chart Titles
    chart1.append("text")
        .attr("x", width2 / 2.5)
        .attr("y", padding.t / 3)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .style("font-weight", "bold")
        .text("Fat Percentage by Cereal");

    chart2.append("text")
        .attr("x", width / 1.6)
        .attr("y", padding.t / 3)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .style("font-weight", "bold")
        .text("Protein vs Carb");

    // Add Axes with Labels
    chart1.append("g")
        .attr("transform", "translate(50," + (height - 90) + ")")
        .call(xAxis)
        .selectAll("text").style("text-anchor", "start").attr("transform", "translate(5, 0) rotate(55)");
    chart1.append("g").attr("transform", "translate(50, 0)").call(yAxis);

    chart1.append("text")
        .attr("x", barChartWidth / 2)
        .attr("y", height + 40)
        .attr("text-anchor", "middle")
        .style("font-weight", "bold")
        .text("Cereal Name");

    chart1.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -chartHeight / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .style("font-weight", "bold")
        .text("Fat");

    // Scatterplot Axes and Labels
    chart2.append("g")
        .attr("transform", "translate(0," + (width - 30) + ")")
        .call(xAxis2);

    chart2.append("g").attr("transform", "translate(50, 0)").call(yAxis2);

    chart2.append("text")
        .attr("x", width / 2)
        .attr("y", height)
        .attr("text-anchor", "middle")
        .style("font-weight", "bold")
        .text("Protein");

    chart2.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -chartHeight / 2)
        .attr("y", 20)
        .attr("text-anchor", "middle")
        .style("font-weight", "bold")
        .text("Carb");

    // Create Histogram Bars
    var bars = chart1.selectAll(".bar").data(csv).enter().append("rect")
        .attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal")
        .attr("x", d => xScale(d.CerealName) + 50)
        .attr("y", d => yScale(d.Fat))
        .attr("width", xScale.bandwidth())
        .attr("height", d => chartHeight - yScale(d.Fat));

    // Create Scatterplot Circles
    var circles = chart2.selectAll(".circle").data(csv).enter().append("circle")
        .attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal")
        .attr("cx", d => xScale2(d.Protein))
        .attr("cy", d => yScale2(d.Carb))
        .attr("r", 5)
        .attr("stroke", "black");

    // Legend Colors with Black Outline
    d3.select("#LowCalorie").append("circle")
        .attr("cx", 10)
        .attr("cy", 6)
        .attr("r", 5)
        .attr("class", "low-cal")
        .attr("stroke", "black");

    d3.select("#MedCalorie").append("circle")
        .attr("cx", 10)
        .attr("cy", 6)
        .attr("r", 5)
        .attr("class", "med-cal")
        .attr("stroke", "black");

    d3.select("#HighCalorie").append("circle")
        .attr("cx", 10)
        .attr("cy", 6)
        .attr("r", 5)
        .attr("class", "high-cal")
        .attr("stroke", "black");

    // Brush for Scatterplot
    var brushScatter = d3.brush()
        .extent([[0, 0], [width, height]])
        .on("start", brushstart)
        .on("brush", highlightBrushedCircles)
        .on("end", displayValues);

    chart2.append("g").attr("class", "brush").call(brushScatter);

    var brushBars = d3.brushX()
        .extent([[0, 0], [width2, chartHeight]])
        .on("start", brushstart)
        .on("brush", highlightBrushedBars)
        .on("end", displayValues);

    chart1.append("g").attr("class", "brush").call(brushBars);


    function brushstart() {
        bars.attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal");
        circles.attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal");
    }
// highlight circles
    function highlightBrushedCircles() {
        var selection = d3.event.selection;
        if (selection) {
            var [[x0, y0], [x1, y1]] = selection;
            circles.attr("class", d => {
                if (xScale2(d.Protein) >= x0 && xScale2(d.Protein) <= x1 && yScale2(d.Carb) >= y0 && yScale2(d.Carb) <= y1) {
                    return d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal";
                } else {
                    return "non_brushed";
                }
            });
            
            bars.attr("class", d => {
                if (xScale2(d.Protein) >= x0 && xScale2(d.Protein) <= x1 && yScale2(d.Carb) >= y0 && yScale2(d.Carb) <= y1) {
                    return d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal";
                } else {
                    return "non_brushed";
                }
            });
        }
    }
// highlight bars
    function highlightBrushedBars() {
        var selection = d3.event.selection;
        if (selection) {
            var [x0, x1] = selection;
            bars.attr("class", d => {
                // Highlight bars within the selection range on the X-axis
                if (xScale(d.CerealName) + 50 >= x0 && xScale(d.CerealName) + 50 <= x1) {
                    return d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal";
                } else {
                    return "non_brushed";
                }
            });

            circles.attr("class", d => {
                if (xScale(d.CerealName) + 50 >= x0 && xScale(d.CerealName) + 50 <= x1) {
                    return d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal";
                } else {
                    return "non_brushed";
                }
            });
        }
    }
// show values
    function displayValues() {
        if (!d3.event.selection) {
            circles.attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal");
            bars.attr("class", d => d.Calories <= 100 ? "low-cal" : d.Calories <= 130 ? "med-cal" : "high-cal");
        }
    }
});
# CS4460-lab6

How to deploy: 
1. Navigate to the cs4460-lab6 folder
2. Make sure python is installed and enter the following script: python3 -m http.server 8080
3. open localhost:8080 in a browser
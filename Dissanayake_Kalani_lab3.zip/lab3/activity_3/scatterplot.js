// **** Your JavaScript code goes here ****
// Tooltip 
var tooltip = d3.select('body').append('div')
.attr('class', 'tooltip')
.style('position', 'absolute')
.style('background-color', 'white')
.style('border', '1px solid black')
.style('padding', '5px')
.style('border-radius', '5px')
.style('opacity', 0);
// Load the data
d3.csv('PokemonExtended.csv').then(function(data) {
    console.log('D3 version:', d3.version);
    console.log("Data loaded:", data);

    // Convert attack, defense, and speed values to numbers
    data.forEach(d => {
        d.attack = +d.Attack;
        d.defense = +d.Defense;
        d.speed = +d.Speed;
    });

    // **** Functions to call for scaled values ****

    function scaleAttack(attack) {
        return attackScale(attack);
    }

    function scaleDefense(defense) {
        return defenseScale(defense);
    }

    function scaleSpeed(speed) {
        return speedScale(speed);
    }
    

    // **** Start of Code for creating scales for axes and data plotting****

    var attackScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.attack))
        .range([60, 700]);

    var defenseScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.defense))
        .range([340, 20]);

    // Scale for the speed attribute, mapping to a radius range
    var speedScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.speed))
        .range([3, 10]);

    var svg = d3.select('svg');

    // **** End of Code for creating scales for axes and data plotting****

    // X-axis
    var xAxis = d3.axisBottom(attackScale);
    svg.append('g')
        .attr('transform', 'translate(0,340)') // Moves the x-axis to the bottom of the chart
        .call(xAxis);

    svg.append("text")
        .attr("x", 350)
        .attr("y", 380)
        .style("text-anchor", "middle")
        .text("Attack");

    // Y-axis 
    var yAxis = d3.axisLeft(defenseScale);
    svg.append('g')
        .attr('transform', 'translate(60, 0)') // Moves the y-axis to the left of the chart
        .call(yAxis);

    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -180)
        .attr("y", 20)
        .style("text-anchor", "middle")
        .text("Defense");

    // Title
    svg.append("text")
        .attr("x", 350)
        .attr("y", 30)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .text("Pokemon Attack vs Defense");


    // Plot the points & scale radius by speed 
    svg.selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', d => scaleAttack(d.attack))
        .attr('cy', d => scaleDefense(d.defense))
        .attr('r', d => scaleSpeed(d.speed))
        .attr('fill', function(d) { return d.speed > 100 ? 'yellow' : 'steelblue'; })
        .attr('opacity', 0.7)
        .on('mouseover', function(d) {
            var event = d3.event;
        
            tooltip.transition().duration(200).style('opacity', 1);
            tooltip.html(`<strong>${d.Name}</strong><br>
                          Type 1: ${d['Type 1']}
                          ${d['Type 2'] ? '<br>Type 2: ' + d['Type 2'] : ''}`)
                .style('left', (event.pageX + 20) + 'px')
                .style('top', (event.pageY - 20) + 'px');
        
            const type1 = d['Type 1'];
            const type2 = d['Type 2'];
        
            svg.selectAll('circle')
                .attr('opacity', function(o) {
                    return (o['Type 1'] === type1 || o['Type 2'] === type1 ||
                            o['Type 1'] === type2 || o['Type 2'] === type2) ? 1 : 0.1;
                });
        })
        .on('mouseout', function(d) {
            tooltip.transition().duration(200).style('opacity', 0);
        
            svg.selectAll('circle')
                .attr('opacity', 0.7);
        });
               
    svg.selectAll('circle').style('fill', function(d) {
            return d.speed > 100 ? 'yellow' : 'steelblue';
    });
});
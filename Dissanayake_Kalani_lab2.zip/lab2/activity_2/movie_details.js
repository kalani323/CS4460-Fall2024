// **** Your JavaScript code goes here ****

// Copy and paste your data structure from the previous activity
const movies = [
    {
      title: "Crazy Rich Asians",
      director: "Jon M. Chu",
      releaseYear: 2018,
      genre: "Romantic Comedy",
      rating: 7.0,
      boxOffice: 238.5
    },
    {
      title: "To All the Boys I've Loved Before",
      director: "Susan Johnson",
      releaseYear: 2018,
      genre: "Romantic Comedy",
      rating: 7.1,
      boxOffice: 60.0
    },
    {
      title: "Anyone But You",
      director: "Will Gluck",
      releaseYear: 2023,
      genre: "Romantic Comedy",
      rating: 6.8,
      boxOffice: 45.0
    }
  ];
  
  function adjustRating(movie, adjustment) {
      // TODO: Return the new rating for movie adjusted by adjustment
      let newRating = movie.rating + adjustment;
      newRating = Math.max(0, Math.min(10, newRating)); // Ensure rating is between 0 and 10
      movie.rating = newRating;
      return newRating;
  }
  
  function debugMovies(movies) {
      // TODO: Loop through the movies list and log their title and new rating
      movies.forEach(movie => {
          console.log(`Title: ${movie.title}, New Rating: ${movie.rating}`);
      });
  }
  
  function calculateAverageRating(movies) {
      // TODO: Calculate average rating of movies
      let totalRating = movies.reduce((sum, movie) => sum + movie.rating, 0);
      return totalRating / movies.length;
  }
  
  function findHighestGrossing(movies) {
      // TODO: Find highest grossing movie's title
      let highestGrossingMovie = movies.reduce((max, movie) => movie.boxOffice > max.boxOffice ? movie : max, movies[0]);
      return highestGrossingMovie.title;
  }
  
  // Changing the DOM with JavaScript
  
  // Starter Code
  var main = document.getElementById("main");
  var header = document.createElement("h1");
  main.appendChild(header);
  header.textContent = "Movies Information";
  var div1 = document.createElement("div");
  div1.setAttribute("id", "movie-container");
  main.appendChild(div1);
  

  function displayMovieCount(movies) {
    // TODO: Display movie count as specified in the readMe
    let countMessage = `Total Movies: ${movies.length}`;
    let countElement = document.createElement("p");
    countElement.style.fontWeight = "bold";
    countElement.textContent = countMessage;
    main.appendChild(countElement);
}
  
  function createMovieCards(movies) {
      // TODO: Create movie card for each movie in movies
      movies.forEach(movie => {
        let card = document.createElement("div");
        card.className = "movie-card";
        card.style.marginBottom = "20px";

        let title = document.createElement("h2");
        title.style.fontWeight = "bold";
        title.textContent = movie.title;
        card.appendChild(title);

        let director = document.createElement("p");
        director.textContent = `Director: ${movie.director}`;
        card.appendChild(director);

        let year = document.createElement("p");
        year.textContent = `Year: ${movie.releaseYear}`;
        card.appendChild(year);

        let genre = document.createElement("p");
        genre.textContent = `Genre: ${movie.genre}`;
        card.appendChild(genre);

        let rating = document.createElement("p");
        rating.textContent = `Rating: ${movie.rating}`;
        card.appendChild(rating);

        let boxOffice = document.createElement("p");
        boxOffice.textContent = `Box Office: ${movie.boxOffice}`;
        card.appendChild(boxOffice);

        main.appendChild(card);
    });
  }
  
  // Extra Credit
  function highlightHighlyRated(minRating) {
      // TODO: highlight highly rated movie cards
      // Extra Credit

    let cards = document.getElementsByClassName("movie-card");
    Array.from(cards).forEach(card => {
        let ratingText = Array.from(card.getElementsByTagName("p"))
            .find(p => p.textContent.startsWith("Rating:"))
            .textContent;
        let rating = parseFloat(ratingText.split("Rating: ")[1]);
        if (rating >= minRating) {
            card.classList.add("highly-rated");
        }
    });
  }
  
  // Main function
  function initializeMoviePage(movies) {
      // TODO: Call the above functions in the correct order to set up your movie page
      displayMovieCount(movies);
    createMovieCards(movies);
    highlightHighlyRated(7.0);
    debugMovies(movies);
    console.log(`Average Rating: ${calculateAverageRating(movies)}`);
    console.log(`Highest Grossing Movie: ${findHighestGrossing(movies)}`);
  }
  

  initializeMoviePage(movies);
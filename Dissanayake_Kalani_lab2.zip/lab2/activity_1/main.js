// **** Your JavaScript code goes here ****
// Create the movieList data structure
const movieList = [
    {
      title: "Crazy Rich Asians",
      director: "Jon M. Chu",
      releaseYear: 2018,
      genre: "Romantic Comedy",
      rating: 7.0,
      boxOffice: 238.5
    },
    {
      title: "To All the Boys I've Loved Before",
      director: "Susan Johnson",
      releaseYear: 2018,
      genre: "Romantic Comedy",
      rating: 7.1,
      boxOffice: 60.0
    },
    {
      title: "Anyone But You",
      director: "Will Gluck",
      releaseYear: 2023,
      genre: "Romantic Comedy",
      rating: 6.8,
      boxOffice: 45.0
    }
  ];
  
  console.log("Movie List:", movieList);
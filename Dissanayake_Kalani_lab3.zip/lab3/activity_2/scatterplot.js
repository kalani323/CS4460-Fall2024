// **** Your JavaScript code goes here ****

// Load the data
d3.csv('PokemonExtended.csv').then(function(data) {
    // Convert attack, defense, and speed values to numbers
    data.forEach(d => {
        d.attack = +d.Attack;
        d.defense = +d.Defense;
        d.speed = +d.Speed;
    });

    // **** Functions to call for scaled values ****
    function scaleAttack(attack) {
        return attackScale(attack);
    }

    function scaleDefense(defense) {
        return defenseScale(defense);
    }

    function scaleSpeed(speed) {
        return speedScale(speed);
    }
    
    // **** Start of Code for creating scales for axes and data plotting ****

    var attackScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.attack))
        .range([60, 700]);

    var defenseScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.defense))
        .range([340, 20]);

    // Scale for the speed attribute, mapping to a radius range
    var speedScale = d3.scaleLinear()
        .domain(d3.extent(data, d => d.speed))
        .range([3, 10]);

    var svg = d3.select('svg');

    // **** End of Code for creating scales for axes and data plotting ****

    // X-axis - Append to svg (axis and label)
    var xAxis = d3.axisBottom(attackScale);
    svg.append('g')
        .attr('transform', 'translate(0,340)') // Moves the x-axis to the bottom of the chart
        .call(xAxis);

    // X-axis label
    svg.append("text")
        .attr("x", 350)
        .attr("y", 380)
        .style("text-anchor", "middle")
        .text("Attack");

    // Y-axis - Append to svg (axis and label)
    var yAxis = d3.axisLeft(defenseScale);
    svg.append('g')
        .attr('transform', 'translate(60, 0)') // Moves the y-axis to the left of the chart
        .call(yAxis);

    // Y-axis label
    svg.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -180)
        .attr("y", 20)
        .style("text-anchor", "middle")
        .text("Defense");

    // Title - Append to svg
    svg.append("text")
        .attr("x", 350)
        .attr("y", 30)
        .attr("text-anchor", "middle")
        .style("font-size", "16px")
        .text("Pokemon Attack vs Defense");

    // Plot the points & scale radius by speed - Enter and append
    svg.selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', d => scaleAttack(d.attack))
        .attr('cy', d => scaleDefense(d.defense))
        .attr('r', d => scaleSpeed(d.speed))
        .attr('fill', 'steelblue')
        .attr('opacity', 0.7);

    // Highlight Pokemon with speed greater than 100
    svg.selectAll('circle')
        .style('fill', function(d) {
            return d.speed > 100 ? 'yellow' : 'steelblue';
        });
});
